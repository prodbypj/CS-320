package appointment;

/*
 * Name: Peyton Johnston
 * Course: CS 320
 * Assignment: Module Five Milestone
 * File: Appointment.java
 * Description: This class creates an appointment object and validates
 * the appointment ID, appointment date, and description.
 */

import java.util.Date;

public class Appointment {
    // The appointment ID is final because it cannot be updated after creation.
    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Checks that the appointment ID is not null and is not longer than 10 characters.
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }

        // Checks that the appointment date is not null and is not in the past.
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        // Checks that the description is not null and is not longer than 50 characters.
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Returns the appointment ID.
    public String getAppointmentId() {
        return appointmentId;
    }

    // Returns the appointment date.
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Returns the appointment description.
    public String getDescription() {
        return description;
    }

    // Updates the appointment date after checking that it is valid.
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        this.appointmentDate = appointmentDate;
    }

    // Updates the description after checking that it is valid.
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.description = description;
    }
}
