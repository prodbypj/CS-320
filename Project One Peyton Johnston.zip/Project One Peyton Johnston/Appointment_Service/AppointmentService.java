package appointment;

/*
 * Name: Peyton Johnston
 * Course: CS 320
 * Assignment: Module Five Milestone
 * File: AppointmentService.java
 * Description: This service class stores appointment objects in memory
 * and allows appointments to be added, found, and deleted by ID.
 */

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
    // Stores appointments in memory because no database is required for this assignment.
    private final ArrayList<Appointment> appointments = new ArrayList<>();

    // Adds a new appointment only if the appointment ID is unique.
    public void addAppointment(String appointmentId, Date appointmentDate, String description) {
        if (findAppointment(appointmentId) != null) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }

        appointments.add(new Appointment(appointmentId, appointmentDate, description));
    }

    // Deletes an appointment using the appointment ID.
    public void deleteAppointment(String appointmentId) {
        Appointment appointment = findAppointment(appointmentId);

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment ID not found");
        }

        appointments.remove(appointment);
    }

    // Searches through the list and returns the appointment with the matching ID.
    public Appointment findAppointment(String appointmentId) {
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentId().equals(appointmentId)) {
                return appointment;
            }
        }

        return null;
    }
}
