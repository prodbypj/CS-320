package appointment;

/*
 * Name: Peyton Johnston
 * Course: CS 320
 * Assignment: Module Five Milestone
 * File: AppointmentServiceTest.java
 * Description: This test class checks that AppointmentService can add,
 * find, and delete appointments while preventing duplicate IDs.
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

    // Creates a future date for valid appointment service testing.
    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();

        service.addAppointment("12345", futureDate(), "Dentist appointment");

        assertNotNull(service.findAppointment("12345"));
        assertEquals("Dentist appointment", service.findAppointment("12345").getDescription());
    }

    @Test
    void testAddAppointmentWithDuplicateIdThrowsException() {
        AppointmentService service = new AppointmentService();

        service.addAppointment("12345", futureDate(), "Dentist appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("12345", futureDate(), "Doctor appointment");
        });
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();

        service.addAppointment("12345", futureDate(), "Dentist appointment");
        service.deleteAppointment("12345");

        assertNull(service.findAppointment("12345"));
    }

    @Test
    void testDeleteAppointmentThatDoesNotExistThrowsException() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("12345");
        });
    }

    @Test
    void testFindAppointmentReturnsCorrectAppointment() {
        AppointmentService service = new AppointmentService();

        service.addAppointment("12345", futureDate(), "Dentist appointment");
        service.addAppointment("67890", futureDate(), "Doctor appointment");

        Appointment appointment = service.findAppointment("67890");

        assertNotNull(appointment);
        assertEquals("67890", appointment.getAppointmentId());
        assertEquals("Doctor appointment", appointment.getDescription());
    }
}
