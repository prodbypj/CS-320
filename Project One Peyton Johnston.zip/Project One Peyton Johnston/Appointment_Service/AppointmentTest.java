package appointment;

/*
 * Name: Peyton Johnston
 * Course: CS 320
 * Assignment: Module Five Milestone
 * File: AppointmentTest.java
 * Description: This test class checks that the Appointment class follows
 * the required validation rules for ID, date, and description.
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentTest {

    // Creates a future date for valid appointment testing.
    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    // Creates a past date for invalid appointment testing.
    private Date pastDate() {
        return new Date(System.currentTimeMillis() - 86400000);
    }

    @Test
    void testAppointmentCreatedSuccessfully() {
        Appointment appointment = new Appointment("1234567890", futureDate(), "Doctor appointment");

        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals("Doctor appointment", appointment.getDescription());
        assertNotNull(appointment.getAppointmentDate());
    }

    @Test
    void testAppointmentIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate(), "Doctor appointment");
        });
    }

    @Test
    void testAppointmentIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate(), "Doctor appointment");
        });
    }

    @Test
    void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Doctor appointment");
        });
    }

    @Test
    void testAppointmentDateCannotBeInPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate(), "Doctor appointment");
        });
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate(), null);
        });
    }

    @Test
    void testDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate(), "This description is longer than fifty characters total.");
        });
    }

    @Test
    void testSetAppointmentDate() {
        Appointment appointment = new Appointment("12345", futureDate(), "Doctor appointment");
        Date newDate = new Date(System.currentTimeMillis() + 172800000);

        appointment.setAppointmentDate(newDate);

        assertEquals(newDate, appointment.getAppointmentDate());
    }

    @Test
    void testSetAppointmentDateCannotBeNull() {
        Appointment appointment = new Appointment("12345", futureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(null);
        });
    }

    @Test
    void testSetAppointmentDateCannotBeInPast() {
        Appointment appointment = new Appointment("12345", futureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(pastDate());
        });
    }

    @Test
    void testSetDescription() {
        Appointment appointment = new Appointment("12345", futureDate(), "Doctor appointment");

        appointment.setDescription("Updated appointment");

        assertEquals("Updated appointment", appointment.getDescription());
    }

    @Test
    void testSetDescriptionCannotBeNull() {
        Appointment appointment = new Appointment("12345", futureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
    }

    @Test
    void testSetDescriptionCannotBeLongerThanFiftyCharacters() {
        Appointment appointment = new Appointment("12345", futureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("This description is longer than fifty characters total.");
        });
    }
}
