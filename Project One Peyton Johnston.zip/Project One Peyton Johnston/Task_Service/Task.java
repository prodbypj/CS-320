/*
 * Author: Peyton Johnston
 * CS 320 Module Four Milestone
 *
 * This class represents one task object for the mobile application.
 * The task ID is final because the requirements say it cannot be updated.
 */

public class Task {
    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        // Validate the task ID before assigning it since it is required and cannot be changed later.
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }

        // The name field is required and must stay within the 20 character limit.
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        // The description field is required and must stay within the 50 character limit.
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        // The task name can be updated, but it still has to follow the same requirements.
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        this.name = name;
    }

    public void setDescription(String description) {
        // The task description can be updated, but it still has to follow the same requirements.
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.description = description;
    }
}
