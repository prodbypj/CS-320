/*
 * Author: Peyton Johnston
 * CS 320 Module Four Milestone
 *
 * This service stores task objects in memory and allows tasks to be
 * added, deleted, and updated by task ID.
 */

import java.util.ArrayList;

public class TaskService {
    private final ArrayList<Task> taskList = new ArrayList<Task>();

    public void addTask(Task task) {
        // A null task should not be added to the list.
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }

        // Each task ID must be unique, so the list is checked before adding a new task.
        for (Task currentTask : taskList) {
            if (currentTask.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("Task ID already exists");
            }
        }

        taskList.add(task);
    }

    public void deleteTask(String taskId) {
        Task taskToDelete = findTask(taskId);

        // If the task cannot be found, the service should not silently ignore the request.
        if (taskToDelete == null) {
            throw new IllegalArgumentException("Task not found");
        }

        taskList.remove(taskToDelete);
    }

    public void updateTaskName(String taskId, String name) {
        Task taskToUpdate = findTask(taskId);

        // Updates are only allowed when the task ID already exists.
        if (taskToUpdate == null) {
            throw new IllegalArgumentException("Task not found");
        }

        taskToUpdate.setName(name);
    }

    public void updateTaskDescription(String taskId, String description) {
        Task taskToUpdate = findTask(taskId);

        // Updates are only allowed when the task ID already exists.
        if (taskToUpdate == null) {
            throw new IllegalArgumentException("Task not found");
        }

        taskToUpdate.setDescription(description);
    }

    public Task getTask(String taskId) {
        return findTask(taskId);
    }

    private Task findTask(String taskId) {
        // This helper method keeps the search logic in one place.
        for (Task currentTask : taskList) {
            if (currentTask.getTaskId().equals(taskId)) {
                return currentTask;
            }
        }

        return null;
    }
}
