/*
 * Author: Peyton Johnston
 * CS 320 Module Four Milestone
 *
 * These unit tests check the TaskService class requirements, including
 * adding tasks, preventing duplicate IDs, deleting tasks, and updating fields.
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

    @Test
    void testAddTask() {
        // This test checks that a valid task can be added and found by ID.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        service.addTask(task);

        assertEquals(task, service.getTask("1234567890"));
    }

    @Test
    void testAddDuplicateTaskId() {
        // The service should not allow two tasks with the same task ID.
        TaskService service = new TaskService();
        Task taskOne = new Task("1234567890", "Homework", "Complete module four milestone");
        Task taskTwo = new Task("1234567890", "Study", "Study for software testing quiz");

        service.addTask(taskOne);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(taskTwo);
        });
    }

    @Test
    void testAddNullTask() {
        // The service should reject a null task instead of adding it to the list.
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(null);
        });
    }

    @Test
    void testDeleteTask() {
        // This test checks that a task can be deleted by its task ID.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        service.addTask(task);
        service.deleteTask("1234567890");

        assertNull(service.getTask("1234567890"));
    }

    @Test
    void testDeleteTaskNotFound() {
        // The service should throw an exception if the task ID does not exist.
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("1234567890");
        });
    }

    @Test
    void testUpdateTaskName() {
        // This test checks that the name field can be updated by task ID.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        service.addTask(task);
        service.updateTaskName("1234567890", "Updated Name");

        assertEquals("Updated Name", service.getTask("1234567890").getName());
    }

    @Test
    void testUpdateTaskDescription() {
        // This test checks that the description field can be updated by task ID.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        service.addTask(task);
        service.updateTaskDescription("1234567890", "Updated description");

        assertEquals("Updated description", service.getTask("1234567890").getDescription());
    }

    @Test
    void testUpdateNameForTaskNotFound() {
        // A task cannot be updated if the task ID is not already in the service.
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("1234567890", "Updated Name");
        });
    }

    @Test
    void testUpdateDescriptionForTaskNotFound() {
        // A task cannot be updated if the task ID is not already in the service.
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("1234567890", "Updated description");
        });
    }

    @Test
    void testUpdateNameMoreThan20Characters() {
        // The service should still enforce the name length requirement during updates.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("1234567890", "This name is too long");
        });
    }

    @Test
    void testUpdateNameNull() {
        // The service should still enforce the null name requirement during updates.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("1234567890", null);
        });
    }

    @Test
    void testUpdateDescriptionMoreThan50Characters() {
        // The service should still enforce the description length requirement during updates.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("1234567890",
                    "This description is more than fifty characters long for testing");
        });
    }

    @Test
    void testUpdateDescriptionNull() {
        // The service should still enforce the null description requirement during updates.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("1234567890", null);
        });
    }
}
