/*
 * Author: Peyton Johnston
 * CS 320 Module Four Milestone
 *
 * These unit tests check the Task class requirements, including
 * valid object creation, field length limits, and null checks.
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testTaskCreatedSuccessfully() {
        // This test checks that a task can be created when all values meet the requirements.
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        assertEquals("1234567890", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Complete module four milestone", task.getDescription());
    }

    @Test
    void testTaskIdMoreThan10Characters() {
        // Task IDs cannot be more than 10 characters.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework", "Complete module four milestone");
        });
    }

    @Test
    void testTaskIdNull() {
        // Task IDs are required and cannot be null.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Complete module four milestone");
        });
    }

    @Test
    void testNameMoreThan20Characters() {
        // The constructor should reject a name that is too long.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "This name is too long", "Complete module four milestone");
        });

        // The setter should also reject a name that is too long.
        assertThrows(IllegalArgumentException.class, () -> {
            Task task = new Task("1234567890", "Homework", "Complete module four milestone");
            task.setName("This name is too long");
        });
    }

    @Test
    void testNameNull() {
        // The constructor should reject a null name.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", null, "Complete module four milestone");
        });

        // The setter should also reject a null name.
        assertThrows(IllegalArgumentException.class, () -> {
            Task task = new Task("1234567890", "Homework", "Complete module four milestone");
            task.setName(null);
        });
    }

    @Test
    void testDescriptionMoreThan50Characters() {
        // The constructor should reject a description that is too long.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Homework",
                    "This description is more than fifty characters long for testing");
        });

        // The setter should also reject a description that is too long.
        assertThrows(IllegalArgumentException.class, () -> {
            Task task = new Task("1234567890", "Homework", "Complete module four milestone");
            task.setDescription("This description is more than fifty characters long for testing");
        });
    }

    @Test
    void testDescriptionNull() {
        // The constructor should reject a null description.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Homework", null);
        });

        // The setter should also reject a null description.
        assertThrows(IllegalArgumentException.class, () -> {
            Task task = new Task("1234567890", "Homework", "Complete module four milestone");
            task.setDescription(null);
        });
    }

    @Test
    void testTaskIdIsNotUpdatable() {
        // The task ID is final and has no setter, so it should stay the same after creation.
        Task task = new Task("1234567890", "Homework", "Complete module four milestone");

        assertEquals("1234567890", task.getTaskId());
    }
}
